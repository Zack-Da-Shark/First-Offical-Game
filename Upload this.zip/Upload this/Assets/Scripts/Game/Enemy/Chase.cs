using UnityEngine;
using System.Collections;


public class Chase : MonoBehaviour
{
    private Transform target;
    private Vector2 memory;
    public LayerMask obstacleMask;

    public float speed = 5f;
    public float angle = 170f;
    public float range = 20f;
    public float radius = 0.1f;
    private Rigidbody2D rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }


    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").transform;
    }
Coroutine memoryRoutine;

void Update()
{
    if (TargetDetected(target))
    {
        memory = target.position;

        if (memoryRoutine != null)
        {
            StopCoroutine(memoryRoutine);
            memoryRoutine = null;
        }

        ChaseTarget();
    }
    else
    {
        if (memoryRoutine == null)
            memoryRoutine = StartCoroutine(ChaseMemory());
    }
}

    public bool TargetDetected(Transform target)
    {
        if (CanHearTarget(target))
            return true;

        if (CanSeeTarget(target))
            return true;

        return false;
    }

    bool CanHearTarget(Transform target)
    {
        float distance = Vector2.Distance(transform.position, target.position);
        Vector2 toTarget = target.position - transform.position;
        Vector2 direction = toTarget.normalized;
        Vector2 origin = transform.position;

        RaycastHit2D hit = Physics2D.Raycast(
            origin,
            direction,
            distance,
            obstacleMask
        );

        if(distance <= radius)
        return hit.collider == null;
        else return false;
    }

    bool CanSeeTarget(Transform target)
    {
        Vector2 origin = transform.position;
        Vector2 toTarget = target.position - transform.position;
        float distance = toTarget.magnitude;

        if (distance > range)
            return false;

        Vector2 direction = toTarget.normalized;
        float angleToTarget = Vector2.Angle(transform.up, direction);

        if (angleToTarget > angle / 2f)
            return false;

        RaycastHit2D hit = Physics2D.Raycast(
            origin,
            direction,
            distance,
            obstacleMask
        );

        return hit.collider == null;
    }

    void ChaseTarget()
    {
        // Move toward player
        transform.position = Vector2.MoveTowards(
            transform.position,
            target.position,
            speed * Time.deltaTime
        );

        // Face player
        transform.up = target.position - transform.position;
    }

    IEnumerator  ChaseMemory()
    {
        while (true)
        {
            transform.position = Vector2.MoveTowards(
                transform.position,
                memory,
                speed * Time.deltaTime
            );

            Vector2 dir = memory - (Vector2)transform.position;
            if (dir != Vector2.zero)
                transform.up = dir;

            // Reached memory → look around
            if (Vector2.Distance(transform.position, memory) < 0.1f)
            {
                transform.Rotate(0f, 0f, 20f);
                yield return new WaitForSeconds(2);

                transform.Rotate(0f, 0f, -60f);
                yield return new WaitForSeconds(2);

                transform.Rotate(0f, 0f, 10f);
                yield return new WaitForSeconds(2);

                yield break; // stop coroutine after search
            }

            yield return null; // wait one frame
        }
    }
}