using UnityEngine;

public class Chase : MonoBehaviour
{
    private Transform target;
    public LayerMask obstacleMask;

    public float speed = 5f;
    public float angle = 170f;
    public float range = 20f;
    private Rigidbody2D rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        if (target != null && TargetSeen(target))
        {
            Vector2 dir = (target.position - transform.position).normalized;
            rb.linearVelocity = dir * speed;
        }
        else
        {
            rb.linearVelocity = Vector2.zero;
        }
    }

    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void Update()
    {
        if (TargetSeen(target))
        {
            // Move toward player
            transform.position = Vector2.MoveTowards(
                transform.position,
                target.position,
                speed * Time.deltaTime
            );

            // Face player
            transform.up = target.position - transform.position;
        }
    }

    public bool TargetSeen(Transform target)
{
    Vector2 origin = transform.position;
    Vector2 direction = (target.position - transform.position).normalized;

    float distance = Vector2.Distance(origin, target.position);
    if (distance > range) return false;

    float angleToTarget = Vector2.Angle(transform.up, direction);
    if (angleToTarget > angle / 2f) return false;

    RaycastHit2D hit = Physics2D.Raycast(
        origin,
        direction,
        distance,
        obstacleMask
    );

    // If we hit a wall before the player → can't see
    if (hit.collider != null)
        return false;

    return true;
}

}
