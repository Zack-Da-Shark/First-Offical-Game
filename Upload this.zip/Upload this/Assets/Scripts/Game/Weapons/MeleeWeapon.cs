using UnityEngine;
using UnityEngine.InputSystem;

public class MeleeWeapon : MonoBehaviour
{
    /* Weapon needs to do the following
    float up and down
    Be pickup-able by any entity
    Can be thrown (1-shot hit depends on weapon weight)
    Must be used for great violence
    */

    //Properties for different weapons
    enum Type
    {
        Blunt,
        HeavyBlunt,
        ShortBlade,
        LongBlade,
        Electric,
        Fragile
    }
    private Transform location;


    private Type type;
    private InputAction pickupAction;
    public InputActionAsset inputActions;

    void Awake()
    {
        pickupAction = inputActions.FindAction("Pickup/Pick up Weapon");
    }

    void OnEnable()
    {
        pickupAction.performed += OnPickUpWeapon;
    }

    void OnDisable()
    {
        pickupAction.performed -= OnPickUpWeapon;
    }


    void Start()
    {
        //Determine what object is the weapon via tags
        //Blunt
        //Heavy Blunt
        //Short Blade
        //Long Blade
        //Electric
        //Fragile

        if(gameObject.CompareTag("Blunt"))
            type = Type.Blunt;
        else if(gameObject.CompareTag("Heavy Blunt"))
            type = Type.HeavyBlunt;
        else if(gameObject.CompareTag("Short blade"))
            type = Type.ShortBlade;
        else if(gameObject.CompareTag("Long Blade"))
            type = Type.LongBlade;
        else if(gameObject.CompareTag("Electric"))
            type = Type.Electric;
        else if(gameObject.CompareTag("Fragile"))
            type = Type.Fragile;

        //Leave the template here
        //else if(gameObject.CompareTag(""))
        //    type = Type.

        InputActionAsset inputActions = Resources.Load<InputActionAsset>("Inputs");
        InputAction pickupAction = inputActions["PickUpWeapon"];
        pickupAction.performed += OnPickUpWeapon;
    }
    
    //If player is within range and presses 'e'
    //Pickup weapon

    // Update is called once per frame
    void Update()
    {
    }

    public void OnPickUpWeapon(InputAction.CallbackContext context)
    {
        //Get position and distanvce from player
        Debug.Log("Attempting to pick up item");
        location = GameObject.FindGameObjectWithTag("Player").transform;
    }
}
